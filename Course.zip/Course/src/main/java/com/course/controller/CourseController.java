package com.course.controller;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.course.entity.CourseEntity;
import com.course.exceptions.CourseNotFoundException;
import com.course.logger.LoggerUtil;
import com.course.service.CourseService;

@RestController

@RequestMapping("/apicourse")

@CrossOrigin(origins = { "*" })

public class CourseController {

	@Autowired

	private CourseService courseService;

	@PostMapping("/course/add")

	public ResponseEntity<String> addCourse(@RequestBody CourseEntity courseEntity) {

		courseService.insert(courseEntity);

		LoggerUtil.logInfo("course details are posted");

		ResponseEntity<String> responseEntity = new ResponseEntity<>("Course Added", HttpStatus.CREATED);

		return responseEntity;

	}

	@GetMapping("/course/all")

	public List<CourseEntity> getAllCourses() throws CourseNotFoundException {

		List<CourseEntity> courses = courseService.findAllCourses();

		LoggerUtil.logInfo("All course details are viewed");

		return courses;

	}

	@DeleteMapping("/course/delete/{id}")

	public ResponseEntity<Object> deleteCourseById(@PathVariable("id") int courseId) throws CourseNotFoundException {

		Optional<Object> optional = courseService.deletecourseById(courseId);

		if (!optional.isPresent()) {

			LoggerUtil.logInfo("course details are deleted");

			return ResponseEntity.status(HttpStatus.BAD_REQUEST)

					.body("Course with course id:" + courseId + " not found!!!");

		}

		Object course = optional.get();

		return ResponseEntity.status(HttpStatus.OK).body(course);

	}

	@GetMapping("/one/{id}")

	public ResponseEntity<Object> getCourseById(@PathVariable("id") int id) throws CourseNotFoundException {

		Optional<CourseEntity> optional = courseService.getCourseById(id);

		if (!optional.isPresent()) {

			LoggerUtil.logInfo("course details are not found");

			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid ID Given");

		}

		CourseEntity course = optional.get();

		return ResponseEntity.status(HttpStatus.OK).body(course);

	}

	@PutMapping("/course/update/{cid}")

	public ResponseEntity<String> editSchedule(@PathVariable("cid") int cid, @RequestBody CourseEntity courseNew)

			throws CourseNotFoundException {

		Optional<CourseEntity> optional = courseService.getCourseById(cid);

		if (!optional.isPresent()) {

			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid ID");

		}

		CourseEntity courseDB = optional.get();

		if (courseNew.getTitle() != null)

			courseDB.setTitle(courseNew.getTitle());

		if (courseNew.getInstructorname() != null)

			courseDB.setInstructorname(courseNew.getInstructorname());

		courseService.postCourseEntity(courseDB);

		LoggerUtil.logInfo("course details are updated");

		return ResponseEntity.status(HttpStatus.OK).body("course Updated");

	}

}