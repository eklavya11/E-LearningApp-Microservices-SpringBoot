package com.course.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.course.entity.CourseEntity;
import com.course.exceptions.CourseNotFoundException;
import com.course.repository.CourseRepository;

@Service

public class CourseService {

	@Autowired

	private CourseRepository courseRepository;

	public void insert(CourseEntity courseEntity) {

		courseRepository.save(courseEntity);

	}

	public List<CourseEntity> findAllCourses() throws CourseNotFoundException {

		return courseRepository.findAll();

	}

	public Optional<Object> deletecourseById(int courseId) throws CourseNotFoundException {

// Check if the course with the given ID exists in the database

		if (!courseRepository.existsById(courseId)) {

			throw new CourseNotFoundException("Course not found with ID: " + courseId);

		}

		courseRepository.deleteById(courseId);

		return null;

	}

	public Optional<CourseEntity> getCourseById(int id) throws CourseNotFoundException {

		Optional<CourseEntity> optional = courseRepository.findById(id);

		return optional;

	}

	public void postCourseEntity(CourseEntity courseDB) throws CourseNotFoundException {

		courseRepository.save(courseDB);

	}

	public Optional<CourseEntity> getCourseById1(int cid) {

		Optional<CourseEntity> optional = courseRepository.findById(cid);

		return optional;

	}

}
